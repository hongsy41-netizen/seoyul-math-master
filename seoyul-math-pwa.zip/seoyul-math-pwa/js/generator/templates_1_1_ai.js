// AI 자동 생성 템플릿
const T11 = [];


window.Templates_1_1 = T11;