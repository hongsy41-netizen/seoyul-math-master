// 외부 DB 문제 분석
const fs = require('fs');

// 전체 단원 목록
const allUnits = {
  'm1-1-1-I-1': '소인수분해',
  'm1-1-1-I-2': '최대공약수와 최소공배수',
  'm1-1-1-II-1': '정수와 유리수',
  'm1-1-1-II-2': '정수와 유리수의 계산',
  'm1-1-1-III-1': '문자의 사용과 식',
  'm1-1-1-III-2': '일차식의 계산',
  'm1-1-1-III-3': '방정식과 그 해',
  'm1-1-1-III-4': '일차방정식의 풀이',
  'm1-1-1-III-5': '일차방정식의 활용',
  'm1-1-2-I-1': '기본 도형',
  'm1-1-2-I-2': '위치 관계',
  'm1-1-2-I-3': '작도와 합동',
  'm1-1-2-II-1': '다각형',
  'm1-1-2-II-2': '원과 부채꼴',
  'm1-1-2-III-1': '다면체와 회전체',
  'm1-1-2-III-2': '입체도형의 겉넓이와 부피'
};

console.log('='.repeat(80));
console.log('📊 외부 DB 문제 단원 분포 분석');
console.log('='.repeat(80));
console.log('\n현재 외부 DB 문제 분포:');
console.log('  m1-1-1-II-2 (정수와 유리수의 계산): 50개');
console.log('  m1-1-1-III-5 (일차방정식의 활용): 350개');
console.log('  총: 400개');

console.log('\n\n❌ 문제점:');
console.log('  - 16개 단원 중 단 2개 단원에만 집중');
console.log('  - 나머지 14개 단원은 외부 DB 문제 없음');
console.log('  - 불균등한 분배');

console.log('\n\n✅ 해결 방안:');
console.log('  1. 외부 DB 문제를 16개 단원에 골고루 재분배');
console.log('  2. 각 단원에 최소 20~30개씩 배치');
console.log('  3. 문제 내용에 따라 적절한 단원에 매핑');

console.log('\n\n🎯 외부 DB 문제 유형 분석:');
const types = [
  '산술연산 - 사칙연산 (m1-1-1-II-2)',
  '순서정하기 - 수의 크기 (m1-1-1-II-1)',
  '조합하기 - 조합 문제 (m1-1-1-I-2)',
  '수찾기1 - 패턴 (m1-1-1-III-1)',
  '수찾기2 - 규칙 (m1-1-1-III-2)',
  '수찾기3 - 조건 (m1-1-1-III-3)',
  '크기비교 - 대소 비교 (m1-1-1-II-1)',
  '도형산술 - 도형 계산 (m1-1-2-II-1, m1-1-2-II-2)'
];

console.log('\n각 유형별로 적절한 단원에 재배치 필요:');
types.forEach((t, i) => {
  console.log(`  ${i+1}. ${t}`);
});

console.log('\n\n💡 권장 재분배:');
Object.keys(allUnits).forEach(unitId => {
  console.log(`  ${unitId} (${allUnits[unitId]}): 20~30개`);
});

console.log('\n='.repeat(80));
console.log('✅ 재분배 스크립트 실행 필요');
console.log('='.repeat(80));
