// 템플릿 통계를 콘솔에 출력
const Templates_1_1 = require('./js/generator/templates_1_1.js');
const Templates_1_2 = require('./js/generator/templates_1_2.js');

// 하지만 브라우저 환경이므로 직접 확인
console.log('템플릿 통계 확인: /check_templates.html 페이지를 열어주세요.');
